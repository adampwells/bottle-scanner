==========================================================================
-The folder "images" contains all the QR code images.
-You can find the name of each QR code image and its content in:
"qrDataCSV.csv", "qrDataTXT.txt" or "qrDataHTML".
==========================================================================
This content has been generated in http://www.qrcoderw.com 
If you have any question, comment, suggestion, or need further information,
please do not hesitate to visit our website and contact us.
==========================================================================
